文件解压后直接命令行在文件所在路径下运行exe文件，
附带参数In2文件complex.in2文件名与标尺数据tapeFile.txt文件名
实例：
.\OrientatingLaunch.exe complex.in2 tapeFile.txt